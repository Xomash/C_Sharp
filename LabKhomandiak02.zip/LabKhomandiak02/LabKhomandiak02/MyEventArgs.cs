﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabKhomandiak02
{
    class MyEventArgs : EventArgs
    {
        public String Message { get; set; }
    }
}
